/** Automatically generated file. DO NOT MODIFY */
package com.example.android.interactivechart;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}