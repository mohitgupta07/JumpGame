package com.example.gme;

public class Kuchbhi extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_kuchbhi);
		RelativeLayout relative = (RelativeLayout) findViewById(R.id.frame);
		ImageView bubbleView = new ImageView(Kuchbhi.this);
		ShapeDrawable shape = new ShapeDrawable(new RectShape());
		bubbleView
				.setImageDrawable(getResources().getDrawable(R.drawable.one1));
		int width = (int) getResources().getDimension(R.dimen.imagewidth);
		int height = (int) getResources().getDimension(R.dimen.imageheight);
		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
				width, height);
		RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(
				width, height);
		params.addRule(RelativeLayout.CENTER_IN_PARENT);
		params2.addRule(RelativeLayout.CENTER_IN_PARENT);
		bubbleView.setLayoutParams(params);
		relative.addView(bubbleView);
		params2.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		shape.setAlpha(100);
		shape.getPaint().setColor(Color.BLUE);
		shape.setIntrinsicHeight(450);
		shape.setIntrinsicWidth(50);
		ImageView shaper = new ImageView(getApplicationContext());
		shaper.setScaleX(4);
		shaper.setImageDrawable(shape);
		shaper.setLayoutParams(params2);
		relative.addView(shaper);
		banja oj = new banja(this, shaper);

	}

}

class banja extends View {
	ImageView image;
	ShapeDrawable r;
	Paint mpaint;
	Bitmap bmp;

	public banja(Context context, ImageView image) {
		super(context);
		// TODO Auto-generated constructor stub
		r = new ShapeDrawable(new RectShape());
		mpaint = new Paint();
		mpaint.setAlpha(50);
		mpaint.setColor(Color.YELLOW);

		// r.setAlpha(100);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		// super.onDraw(canvas);

		canvas.drawText("hellooooo", 15, 45, mpaint);

	}

}