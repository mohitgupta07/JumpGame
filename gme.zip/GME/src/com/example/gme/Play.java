package com.example.gme;

public class Play extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_play);
		final Intent i = new Intent(Play.this, Rayman.class);
		Button play = (Button) findViewById(R.id.buttonPlay);
		play.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				startActivity(i);
				finish();
			}
		});

	}

}
