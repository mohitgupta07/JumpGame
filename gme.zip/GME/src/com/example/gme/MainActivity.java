package com.example.gme;

import android.R;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends ActionBarActivity implements Runnable {
	static int i = 100;
	Thread t;
	ImageView img;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_main);
		// Load the ImageView that will host the animation and
		// set its background to our AnimationDrawable XML resource.
		img = (ImageView) findViewById(R.id.imageview);
		// img.setPadding(45, 45, 45, 45);
		img.setLeft(250);
		img.setBottom(500);
		img.setTranslationX(100);
		img.setTranslationY(400);
		t = new Thread(this);
		t.start();
		Button left = (Button) findViewById(R.id.buttonLeft);
		Button Right = (Button) findViewById(R.id.buttonRight);
		left.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				img.setTranslationX(i = i - 10);
			}
		});
		Right.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				img.setTranslationX(i = i + 10);
			}
		});

		// new Thread(new Runnable() {
		//
		// @Override
		// public void run() {
		// // TODO Auto-generated method stub
		// while (i < 500) {
		//
		// try {
		// i++;
		// img.setTranslationX(i);
		// Thread.sleep(500);
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// }
		// }
		// }).start();

		// img.setBackgroundResource(R.drawable.numbers);
		//
		// // Get the background, which has been compiled to an
		// AnimationDrawable
		// // object.
		// AnimationDrawable frameAnimation = (AnimationDrawable) img
		// .getBackground();
		//
		// // Start the animation (looped playback by default).
		// frameAnimation.start();

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		while (i < 500) {

			try {
				i = i + 10;
				Thread.sleep(400);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			img.post(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub

					img = (ImageView) findViewById(R.id.imageview);
					img.setTranslationX(i);
				}
			});

		}
	}
}
