package com.example.gme;

public class Result extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_result);
		Intent i = getIntent();
		Integer count = i.getIntExtra("count", 0);
		TextView txt = (TextView) findViewById(R.id.textViewResultScore);
		txt.setText(count.toString());
	}

}
