package com.example.gme;

public class yoo extends ValueAnimator{
	ValueAnimator.AnimatorUpdateListener a=new AnimatorUpdateListener() {
		
		@Override
		public void onAnimationUpdate(ValueAnimator arg0) {
			// TODO Auto-generated method stub
			arg0.getAnimatedValue();
			arg0.pause();
		}
	};

}
