package com.example.gme;

public class Rayman extends Activity implements Runnable {
	ImageView tree, tree2, tree3, tree4, tree5, Ray;
	static int move = 1800, move2 = 1600, move3 = 1600, move4 = 2250,
			move5 = 1950, height = 240, choice = 0, jump = 0, hit = 0,
			count = 0;
	EditText score, hitgot;
	Thread t;
	Intent i;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// LayoutInflater inf = getLayoutInflater();
		// getWindow().addContentView(
		// inf.inflate(R.layout.bg, null),
		// new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
		// ViewGroup.LayoutParams.WRAP_CONTENT));
		setContentView(R.layout.fragment_rayman);

		tree = (ImageView) findViewById(R.id.imageViewTree);
		tree2 = (ImageView) findViewById(R.id.imageViewTree2);
		tree3 = (ImageView) findViewById(R.id.imageViewTree3);
		tree4 = (ImageView) findViewById(R.id.imageViewTree4);
		tree5 = (ImageView) findViewById(R.id.imageViewTree5);
		score = (EditText) findViewById(R.id.editTextScore);
		hitgot = (EditText) findViewById(R.id.editTextHit);
		i = new Intent(Rayman.this, Result.class);

		if (choice == 0)
			Ray = (ImageView) findViewById(R.id.imageViewChar);
		Button space = (Button) findViewById(R.id.buttonJump);

		space.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				choice = 3;

			}
		});
		t = new Thread(this);
		t.start();
	}

	@Override
	public void run() {
		if (hit > 100) {
			i.putExtra("count", count);
			startActivity(i);
			finish();
		} else
			while (hit <= 100) {

				move -= 5;
				move2 -= 5;
				move3 -= 8;
				if (count >= 1800)
					move4 -= 10;
				if (count >= 3400)
					move5 -= 12;
				count++;
				score.post(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub

						// score.setText(count + "");
					}
				});
				hitgot.post(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						hitgot.setText(hit + "");
					}
				});

				Random s = new Random();
				if (move <= 0)
					move = 1700 + s.nextInt(300);
				if (move2 <= 0)
					move2 = 1650 + s.nextInt(400);
				if (move3 <= 0)
					move3 = 1800 + s.nextInt(450);
				if (move4 <= 0)
					move4 = 1950 + s.nextInt(800);
				if (move5 <= 0)
					move5 = 2250 + s.nextInt(1000);
				try {
					Thread.sleep(14);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				tree.post(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						tree.setTranslationX(move);
					}
				});
				tree2.post(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						tree2.setTranslationX(move2);
					}
				});

				if (count < 1800)
					tree3.post(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							tree3.setTranslationX(move3);

						}
					});

				if (count >= 1800 && count <= 3400) {

					tree4.post(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							tree4.setTranslationX(move4);
							tree3.setBackgroundResource(0);
							tree3.setTranslationX(2000);
						}
					});
				}
				if (count >= 3400) {

					tree5.post(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							tree5.setTranslationX(move5);
							tree3.setBackgroundResource(0);
							tree3.setTranslationX(2000);
							tree4.setBackgroundResource(0);
							tree4.setTranslationX(2000);
						}
					});
				}
				if (choice == 0) {
					Ray.post(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub

							Ray.setImageResource(R.drawable.abc);

						}
					});

					if ((move >= 45 && move <= (100))) {

						hit++;

					}
					if ((move2 >= 45 && move2 <= (100))) {

						hit++;

					}
					if ((move3 >= 45 && move3 <= (100)) && count < 1800) {

						hit++;

					}
					if ((move4 >= 45 && move4 <= (100)) && count >= 1800
							&& count < 3400) {

						hit++;

					}
					if ((move5 >= 45 && move5 <= (100)) && count >= 3400) {

						hit++;

					}

				}
				// Ray.setImageResource(R.drawable.abc);
				else if (choice == 3) {

					// Ray.setImageResource(R.drawable.charjump);
					jump++;
					if (jump <= 40) {
						height -= 4;
					} else if (jump > 40 && jump <= 80) {
						height += 4;
					} else {
						jump = 0;
						choice = 0;
					}
					if ((move >= 45 && move <= (100)) && (height >= 200)) {

						hit++;

					}
					if ((move2 >= 45 && move2 <= (100)) && (height >= 200)) {

						hit++;

					}
					if ((move3 >= 45 && move3 <= (100)) && (height >= 200)
							&& count < 1800) {

						hit++;

					}
					if ((move4 >= 45 && move4 <= (100)) && (height >= 200)
							&& count >= 1800 && count < 3400) {

						hit++;

					}
					if ((move5 >= 45 && move5 <= (100)) && (height >= 200)
							&& count >= 3400) {

						hit++;

					}

					Ray.post(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub

							// Ray.setImageResource(R.drawable.charjump);

							Ray.setTranslationY(height);
						}
					});
				}
			}

	}
}
